using UnityEngine;

public class DolphinRide : MonoBehaviour
{
    public GameObject dolphin;
    public Transform ridePosition;
    public bool onDolphin = false;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R) && !onDolphin)
        {
            StartRide();
        }
    }

    void StartRide()
    {
        onDolphin = true;
        transform.position = ridePosition.position;
        transform.parent = dolphin.transform;
        dolphin.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 10f);
    }
}