using UnityEngine;
using UnityEngine.SceneManagement;

public class BlackHoleTransition : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            SceneManager.LoadScene("VolcanoLandScene");
        }
    }
}