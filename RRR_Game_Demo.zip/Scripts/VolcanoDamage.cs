using UnityEngine;

public class VolcanoDamage : MonoBehaviour
{
    public int health = 3;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Lava"))
        {
            health--;
            if (health <= 0)
            {
                Debug.Log("Burnt! Game Over!");
            }
        }
    }
}