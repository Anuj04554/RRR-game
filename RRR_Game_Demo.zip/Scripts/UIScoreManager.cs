using UnityEngine;
using UnityEngine.UI;

public class UIScoreManager : MonoBehaviour
{
    public int score = 0;
    public Text scoreText;

    void Update()
    {
        score += 1;
        scoreText.text = "Score: " + score.ToString();
    }
}