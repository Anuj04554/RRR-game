using UnityEngine;

public class SpaceJetRide : MonoBehaviour
{
    public GameObject jet;
    public bool ridingJet = false;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.J) && !ridingJet)
        {
            ActivateJet();
        }
    }

    void ActivateJet()
    {
        ridingJet = true;
        transform.parent = jet.transform;
        jet.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 20f);
    }
}